<?php $__env->startSection('title', 'Committee View - ' . $committee->name); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8" id="committeePortalRoot">

    <!-- Back Navigation -->
    <div class="flex items-center justify-between">
        <a href="<?php echo e(route('member.dashboard')); ?>" class="inline-flex items-center text-xs font-semibold text-slate-400 hover:text-emerald-400 transition-colors">
            <i class="fa-solid fa-arrow-left mr-2"></i> Back to My Committees
        </a>
        <!-- Real-time status indicator -->
        <div id="liveStatusBadge" class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-wider">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse inline-block"></span>
            <span id="liveStatusText">Live Bids — Updating</span>
        </div>
    </div>

    <!-- Header Card -->
    <div class="glass-card p-6 sm:p-8 rounded-3xl border border-slate-800 space-y-6 shadow-2xl relative overflow-hidden">
        <div class="absolute -top-12 -right-12 w-52 h-52 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div class="space-y-2 z-10">
                <div class="flex items-center space-x-3">
                    <h1 class="text-2xl sm:text-3xl font-black text-white tracking-tight"><?php echo e($committee->name); ?></h1>
                    <span class="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                        <?php echo e($committee->total_members); ?> Members
                    </span>
                </div>
                <p class="text-xs sm:text-sm text-slate-400">
                    Live auction bidding board. Submit your bid — all members see bids in real-time. Once organizer approves a bid, that round is locked.
                </p>
            </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-4 border-t border-slate-800 z-10 relative">
            <div class="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
                <span class="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Total Chit Value</span>
                <span class="text-lg font-black text-white font-mono">₹<?php echo e(number_format($committee->total_amount, 2)); ?></span>
            </div>
            <div class="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
                <span class="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Monthly Base Rate</span>
                <span class="text-lg font-black text-amber-400 font-mono"><?php echo e($committee->monthly_rate ?? $committee->deduction_rate); ?>%</span>
            </div>
            <div class="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
                <span class="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Zero Round</span>
                <span class="text-lg font-black text-teal-400 font-mono">Month <?php echo e($committee->zero_deduction_month ?? ($committee->total_members - $committee->special_month_index + 1)); ?></span>
            </div>
            <div class="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
                <span class="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">My Profile / Seats</span>
                <span class="text-sm font-bold text-emerald-300 truncate block"><?php echo e($member->name); ?></span>
                <?php if($totalSeats > 1): ?>
                    <span class="text-[10px] text-purple-300 font-extrabold uppercase block mt-0.5">
                        <i class="fa-solid fa-users-rectangle mr-1"></i><?php echo e($totalSeats); ?> Registered Seats
                    </span>
                <?php endif; ?>
            </div>
            <div class="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
                <span class="block text-[10px] font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1">
                    <i class="fa-solid fa-calendar-plus text-[10px]"></i> Start Date
                </span>
                <span class="text-sm font-bold text-white block mt-0.5"><?php echo e($committee->start_date ? $committee->start_date->format('d M Y') : 'N/A'); ?></span>
            </div>
            <div class="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800">
                <span class="block text-[10px] font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                    <i class="fa-solid fa-calendar-check text-[10px]"></i> End Date
                </span>
                <span class="text-sm font-bold text-emerald-300 block mt-0.5"><?php echo e($committee->end_date ? $committee->end_date->format('d M Y') : 'N/A'); ?></span>
            </div>
        </div>
    </div>

    <!-- Multi-Seat Holder Status Banner -->
    <?php if($totalSeats > 1): ?>
    <div class="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-purple-950/70 via-slate-900 to-purple-950/70 border border-purple-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div class="flex items-center space-x-3.5">
            <div class="w-11 h-11 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-300 flex items-center justify-center text-xl shrink-0">
                <i class="fa-solid fa-users-rectangle"></i>
            </div>
            <div>
                <h3 class="text-sm font-extrabold text-white flex items-center gap-2">
                    <span>Multi-Seat Account: <strong class="text-purple-300 font-mono"><?php echo e($totalSeats); ?> Registered Seats / Entries</strong></span>
                </h3>
                <p class="text-xs text-slate-300 mt-0.5 leading-relaxed">
                    You have won <strong class="text-amber-300 font-mono"><?php echo e($wonCount); ?> of <?php echo e($totalSeats); ?></strong> payouts so far.
                    <?php if($remainingSeats > 0): ?>
                        You still have <strong class="text-emerald-400 font-mono"><?php echo e($remainingSeats); ?> seat(s)</strong> eligible to place live auction bids!
                    <?php else: ?>
                        All of your registered <?php echo e($totalSeats); ?> seats have won payouts for this committee.
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <div class="shrink-0">
            <?php if($remainingSeats > 0): ?>
                <span class="px-3.5 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 shadow-sm">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span><?php echo e($remainingSeats); ?> Bid(s) Available</span>
                </span>
            <?php else: ?>
                <span class="px-3.5 py-1.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5">
                    <i class="fa-solid fa-trophy text-amber-400"></i>
                    <span>All <?php echo e($totalSeats); ?> Seats Won</span>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Already Won Banner (only when payout is fully won for all seats) -->
    <?php if($alreadyWon): ?>
    <div class="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start space-x-4 shadow-lg">
        <div class="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center text-2xl shrink-0">
            <i class="fa-solid fa-trophy"></i>
        </div>
        <div>
            <h3 class="text-base font-extrabold text-amber-300">All Registered Payouts Won</h3>
            <p class="text-xs text-amber-400/80 mt-1 leading-relaxed">
                You have won committee payouts for all <?php echo e($totalSeats); ?> of your registered seats/entries. You can still <strong class="text-amber-300">view all bids and the live board</strong>, but you cannot place new bids.
            </p>
        </div>
    </div>
    <?php endif; ?>

    <?php if($committee->status === 'completed'): ?>
    <div class="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-emerald-950/80 border border-emerald-500/40 flex items-center space-x-4 shadow-xl">
        <div class="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center text-2xl shrink-0">
            <i class="fa-solid fa-lock"></i>
        </div>
        <div>
            <h3 class="text-base font-extrabold text-white flex items-center gap-2">
                <span>COMMITTEE COMPLETED &amp; CLOSED</span>
                <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/30 text-emerald-200 uppercase font-black tracking-wider">Read Only</span>
            </h3>
            <p class="text-xs text-slate-300 mt-1 leading-relaxed">
                This committee has completed all its rounds. You can view all schedule entries, payouts, and past bids in read-only mode.
            </p>
        </div>
    </div>
    <?php endif; ?>

    <!-- Live Auction Board — Per-Round Cards -->
    <div class="space-y-4">
        <div class="flex items-center justify-between">
            <h2 class="text-lg font-bold text-white flex items-center space-x-2">
                <i class="fa-solid fa-gavel text-amber-400"></i>
                <span>Live Auction Bidding Board</span>
            </h2>
            <span class="text-xs text-slate-400">
                <i class="fa-solid fa-clock-rotate-left mr-1 text-emerald-400"></i>
                <span id="lastUpdatedTime">Just loaded</span>
            </span>
        </div>

        <!-- Schedule Rounds as Expandable Cards -->
        <div id="auctionBoardContainer" class="space-y-3">
            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $payment    = $myPayments->get($schedule->id);
                $myBid      = $myBids->get($schedule->id);
                $roundBids  = $allBidsBySchedule->get($schedule->id, collect());
                $isLocked   = (bool) $schedule->is_custom_bid;
                $iAmWinner  = $schedule->member_id == $member->id;

                $effectiveDrawDate = $schedule->draw_date ?? ($committee->start_date ? \Illuminate\Support\Carbon::parse($committee->start_date)->addMonths($schedule->month_no - 1) : null);
                $today = now()->startOfDay();
                $drawDate = $effectiveDrawDate ? \Illuminate\Support\Carbon::parse($effectiveDrawDate)->startOfDay() : null;

                $isBeforeDraw = $drawDate ? $today->lt($drawDate) : false;
                $isTodayDraw  = $drawDate ? $today->eq($drawDate) : true;
                $isAfterDraw  = $drawDate ? $today->gt($drawDate) : false;
            ?>

            <div class="glass-card rounded-2xl border <?php echo e($isLocked ? 'border-emerald-500/40' : 'border-slate-800'); ?> overflow-hidden transition-all"
                 id="schedule-card-<?php echo e($schedule->id); ?>"
                 data-schedule-id="<?php echo e($schedule->id); ?>"
                 data-is-locked="<?php echo e($isLocked ? 'true' : 'false'); ?>"
                 data-date-status="<?php echo e($isBeforeDraw ? 'before' : ($isAfterDraw ? 'after' : 'today')); ?>">

                <!-- Round Header Row (always visible) -->
                <div class="flex items-center justify-between p-4 cursor-pointer select-none"
                     onclick="toggleRoundCard(<?php echo e($schedule->id); ?>)">

                    <div class="flex items-center space-x-3">
                        <!-- Month Badge -->
                        <div class="w-10 h-10 rounded-xl <?php echo e($isLocked ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-300'); ?> border font-black font-mono text-sm flex items-center justify-center shrink-0">
                            <?php echo e($schedule->month_no); ?>

                        </div>

                        <div>
                            <div class="flex items-center space-x-2 flex-wrap gap-y-1">
                                <span class="text-sm font-bold text-white">Month <?php echo e($schedule->month_no); ?></span>
                                <?php if($isLocked): ?>
                                    <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-extrabold uppercase tracking-wider flex items-center space-x-1">
                                        <i class="fa-solid fa-lock text-[9px]"></i>
                                        <span>Bid Approved — Locked</span>
                                    </span>
                                <?php elseif($isBeforeDraw): ?>
                                    <span class="px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20 text-[10px] font-bold uppercase tracking-wider flex items-center space-x-1">
                                        <i class="fa-solid fa-clock text-[9px] text-blue-400"></i>
                                        <span>Bids Open on <?php echo e($drawDate->format('d/m/Y')); ?></span>
                                    </span>
                                <?php elseif($isTodayDraw): ?>
                                    <span class="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20 text-[10px] font-bold uppercase tracking-wider flex items-center space-x-1">
                                        <span class="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse inline-block"></span>
                                        <span>Bidding Open Today!</span>
                                    </span>
                                <?php elseif($isAfterDraw): ?>
                                    <span class="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 text-[10px] font-bold uppercase tracking-wider flex items-center space-x-1">
                                        <i class="fa-solid fa-calendar-xmark text-[9px]"></i>
                                        <span>Bidding Closed (<?php echo e($drawDate->format('d/m/Y')); ?>)</span>
                                    </span>
                                <?php endif; ?>

                                <?php if($iAmWinner): ?>
                                    <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-extrabold uppercase">
                                        <i class="fa-solid fa-trophy mr-1"></i>Your Round
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="flex items-center space-x-4 mt-0.5 text-[11px] text-slate-400 flex-wrap">
                                <span>Draw Date: <strong class="text-white font-mono"><?php echo e($drawDate ? $drawDate->format('d/m/Y') : 'N/A'); ?></strong></span>
                                <span>Net Payout: <strong class="text-emerald-300 font-mono">₹<?php echo e(number_format($schedule->net_payout, 2)); ?></strong></span>
                                <span>Installment: <strong class="text-white font-mono">₹<?php echo e(number_format($schedule->installment_per_member, 2)); ?></strong></span>
                                <span>Bids: <strong class="text-amber-400 font-mono bid-count-<?php echo e($schedule->id); ?>"><?php echo e($roundBids->count()); ?></strong></span>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center space-x-3 shrink-0">
                        <?php
                            $roundIsLocked = (bool)$schedule->is_custom_bid;
                            $iAmThisRoundWinner = ($schedule->member_id == $member->id);
                        ?>

                        <?php if($committee->status === 'completed'): ?>
                            <span class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                                <i class="fa-solid fa-lock text-emerald-400"></i>
                                <span>Committee Closed</span>
                            </span>
                        <?php elseif($alreadyWon): ?>
                            <?php if($iAmThisRoundWinner): ?>
                                <span class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold">
                                    <i class="fa-solid fa-trophy text-amber-400"></i>
                                    <span>Your Won Round</span>
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-500 text-xs font-semibold">
                                    <i class="fa-solid fa-lock text-slate-500"></i>
                                    <span>Payout Received</span>
                                </span>
                            <?php endif; ?>
                        <?php elseif($roundIsLocked): ?>
                            <?php if($iAmThisRoundWinner): ?>
                                <span class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
                                    <i class="fa-solid fa-trophy text-amber-400"></i>
                                    <span>Your Bid Won!</span>
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-semibold">
                                    <i class="fa-solid fa-lock text-rose-400"></i>
                                    <span>Bidding Closed by Organizer</span>
                                </span>
                            <?php endif; ?>
                        <?php elseif($isBeforeDraw): ?>
                            <span class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-semibold cursor-not-allowed"
                                  title="Bidding will open on <?php echo e($drawDate ? $drawDate->format('d/m/Y') : ''); ?>">
                                <i class="fa-solid fa-clock text-blue-400"></i>
                                <span>Opens <?php echo e($drawDate ? $drawDate->format('d/m/Y') : ''); ?></span>
                            </span>
                        <?php elseif($isAfterDraw): ?>
                            <span class="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-400 text-xs font-semibold cursor-not-allowed"
                                  title="Bidding closed on <?php echo e($drawDate ? $drawDate->format('d/m/Y') : ''); ?>">
                                <i class="fa-solid fa-calendar-xmark text-slate-500"></i>
                                <span>Closed <?php echo e($drawDate ? $drawDate->format('d/m/Y') : ''); ?></span>
                            </span>
                        <?php else: ?>
                            
                            <?php if($myBids->has($schedule->id)): ?>
                                <button type="button"
                                    onclick="event.stopPropagation(); openBidModal(<?php echo e($schedule->id); ?>, <?php echo e($schedule->month_no); ?>, <?php echo e($committee->total_amount); ?>, <?php echo e($myBids->get($schedule->id)->bid_amount); ?>, '<?php echo e(addslashes($myBids->get($schedule->id)->remarks ?? '')); ?>')"
                                    class="px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all">
                                    <i class="fa-solid fa-pen-to-square mr-1"></i> Edit Bid (₹<?php echo e(number_format($myBids->get($schedule->id)->bid_amount, 0)); ?>)
                                </button>
                            <?php else: ?>
                                <button type="button"
                                    onclick="event.stopPropagation(); openBidModal(<?php echo e($schedule->id); ?>, <?php echo e($schedule->month_no); ?>, <?php echo e($committee->total_amount); ?>, <?php echo e($schedule->deduction_amount); ?>, '')"
                                    class="px-3 py-1.5 rounded-lg text-xs font-bold bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 transition-all shadow-md shadow-emerald-500/20">
                                    <i class="fa-solid fa-gavel mr-1"></i> Place Bid
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>

                        <i class="fa-solid fa-chevron-down text-slate-500 text-xs transition-transform" id="chevron-<?php echo e($schedule->id); ?>"></i>
                    </div>
                </div>

                <!-- Expandable Bids Section -->
                <div class="hidden border-t border-slate-800/80 p-4 space-y-3" id="round-body-<?php echo e($schedule->id); ?>">

                    <!-- Schedule Stats Row -->
                    <div class="grid grid-cols-3 gap-3">
                        <div class="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                            <span class="block text-[10px] font-semibold text-slate-400 uppercase">Deduction</span>
                            <span class="block font-mono font-bold text-rose-300 text-sm">₹<?php echo e(number_format($schedule->deduction_amount, 2)); ?></span>
                            <?php if($schedule->is_custom_bid): ?>
                                <span class="text-[9px] text-amber-400"><i class="fa-solid fa-gavel mr-0.5"></i>Custom Auction</span>
                            <?php endif; ?>
                        </div>
                        <div class="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                            <span class="block text-[10px] font-semibold text-slate-400 uppercase">Net Payout</span>
                            <span class="block font-mono font-bold text-emerald-400 text-sm">₹<?php echo e(number_format($schedule->net_payout, 2)); ?></span>
                        </div>
                        <div class="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                            <span class="block text-[10px] font-semibold text-slate-400 uppercase">My Payment</span>
                            <?php
                                $memberPayments = $myPayments->get($schedule->id, collect());
                                $paidMemberCount = $memberPayments->where('payment_status', 'paid')->count();
                                $totalMemberSeatsCount = max(1, $totalSeats);
                            ?>
                            <?php if($paidMemberCount === $totalMemberSeatsCount): ?>
                                <span class="block text-xs font-bold text-emerald-300"><i class="fa-solid fa-check mr-1"></i>Paid <?php echo e($totalMemberSeatsCount > 1 ? "({$paidMemberCount}/{$totalMemberSeatsCount})" : ''); ?></span>
                            <?php elseif($paidMemberCount > 0): ?>
                                <span class="block text-xs font-bold text-amber-300"><i class="fa-solid fa-clock mr-1"></i>Partial (<?php echo e($paidMemberCount); ?>/<?php echo e($totalMemberSeatsCount); ?>)</span>
                            <?php else: ?>
                                <span class="block text-xs font-bold text-rose-400"><i class="fa-solid fa-clock mr-1"></i>Pending <?php echo e($totalMemberSeatsCount > 1 ? "(0/{$totalMemberSeatsCount})" : ''); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Live Bids List -->
                    <div>
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                                All Member Bids <span class="text-amber-400 bid-count-<?php echo e($schedule->id); ?>"><?php echo e($roundBids->count()); ?></span>
                            </span>
                            <?php if($schedule->winner): ?>
                                <div class="flex items-center space-x-1.5 text-[11px] font-bold text-emerald-400">
                                    <i class="fa-solid fa-trophy text-amber-400 text-xs"></i>
                                    <span>Winner: <?php echo e($schedule->winner->name); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Bids table — updated via JS polling -->
                        <div class="bid-list-<?php echo e($schedule->id); ?> space-y-1.5">
                            <?php if($roundBids->isEmpty()): ?>
                                <div class="text-center py-4 text-slate-500 text-xs italic" id="no-bids-<?php echo e($schedule->id); ?>">
                                    No bids placed yet for this round. Be the first!
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $roundBids->sortBy('bid_amount'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center justify-between p-2.5 rounded-lg <?php echo e($bid->member_id == $member->id ? 'bg-emerald-500/10 border border-emerald-500/30' : 'bg-slate-900/60 border border-slate-800'); ?>">
                                    <div class="flex items-center space-x-2.5">
                                        <?php if($idx === 0): ?>
                                            <div class="w-6 h-6 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center text-[10px] font-black shrink-0" title="Lowest Bid">
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        <?php else: ?>
                                            <div class="w-6 h-6 rounded-lg bg-slate-800 border border-slate-700 text-slate-400 flex items-center justify-center text-[10px] font-bold shrink-0">
                                                <?php echo e($idx + 1); ?>

                                            </div>
                                        <?php endif; ?>
                                        <div>
                                            <span class="block text-xs font-bold <?php echo e($bid->member_id == $member->id ? 'text-emerald-300' : 'text-white'); ?>">
                                                <?php echo e($bid->member->name ?? 'Unknown'); ?>

                                                <?php if($bid->member_id == $member->id): ?>
                                                    <span class="text-[10px] text-emerald-400">(You)</span>
                                                <?php endif; ?>
                                            </span>
                                            <?php if($bid->remarks): ?>
                                                <span class="block text-[10px] text-slate-400 italic">"<?php echo e($bid->remarks); ?>"</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <span class="block font-mono font-black text-sm <?php echo e($bid->member_id == $member->id ? 'text-emerald-400' : 'text-amber-300'); ?>">
                                            ₹<?php echo e(number_format($bid->bid_amount, 0)); ?>

                                        </span>
                                        <?php if($bid->status === 'approved'): ?>
                                            <span class="text-[10px] text-emerald-400 font-bold"><i class="fa-solid fa-check-circle mr-0.5"></i>Approved</span>
                                        <?php else: ?>
                                            <span class="text-[10px] text-slate-500">Pending Review</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<!-- Submit / Edit Auction Bid Modal -->
<div id="bidModal" class="fixed inset-0 z-50 hidden bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="glass-card w-full max-w-lg p-6 rounded-3xl border border-slate-800 space-y-6 shadow-2xl">
        <div class="flex items-center justify-between border-b border-slate-800 pb-4">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-lg">
                    <i class="fa-solid fa-gavel"></i>
                </div>
                <div>
                    <h3 class="text-base font-bold text-white" id="bidModalTitle">Place Your Auction Bid</h3>
                    <p class="text-xs text-slate-400" id="bidModalSubtitle">Month 1 Round</p>
                </div>
            </div>
            <button type="button" onclick="closeBidModal()" class="text-slate-400 hover:text-white text-lg">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <!-- Current Bid Info (shown only when editing) -->
        <div id="currentBidInfo" class="hidden p-3 rounded-xl bg-amber-500/10 border border-amber-500/30">
            <div class="flex items-center space-x-2 text-xs">
                <i class="fa-solid fa-triangle-exclamation text-amber-400"></i>
                <span class="text-amber-300 font-semibold">
                    Your current bid: <span id="currentBidDisplay" class="font-mono font-black text-amber-200">₹0</span>
                    &nbsp;—&nbsp; You can only <strong>increase</strong> this amount.
                </span>
            </div>
        </div>

        <form id="bidForm" method="POST" action="" data-ajax="true" class="space-y-5">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="committeeTotalAmount" value="<?php echo e($committee->total_amount); ?>">
            <input type="hidden" id="committeeTotalMembers" value="<?php echo e($committee->total_members); ?>">
            <input type="hidden" id="currentBidMin" value="0">  

            <div class="space-y-2">
                <label for="bid_amount" class="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                    Offered Deduction Amount (₹)
                </label>
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-500 font-bold">₹</span>
                    <input type="number" step="1" min="0" max="<?php echo e($committee->total_amount); ?>"
                        name="bid_amount" id="bid_amount" required
                        oninput="calculateBidPreview(); validateBidAmount();"
                        class="w-full glass-input pl-8 pr-4 py-2.5 rounded-xl text-sm font-mono font-bold text-amber-400">
                </div>
                <!-- Validation hint -->
                <div id="bidValidationHint" class="hidden flex items-center space-x-1.5 text-xs text-rose-400 font-semibold">
                    <i class="fa-solid fa-circle-xmark"></i>
                    <span id="bidValidationMsg">Bid must be higher than your current bid.</span>
                </div>
                <p class="text-[11px] text-slate-400" id="bidHelpText">Enter the deduction amount you are willing to offer. Lower deduction = better payout for winner.</p>
            </div>

            <!-- Live preview -->
            <div class="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
                <span class="block text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Live Bid Preview</span>
                <div class="grid grid-cols-2 gap-2 text-xs">
                    <div>
                        <span class="text-slate-400">Estimated Net Payout:</span>
                        <span class="block font-mono font-bold text-emerald-300 text-sm" id="previewNetPayout">₹0.00</span>
                    </div>
                    <div>
                        <span class="text-slate-400">Installment / Member:</span>
                        <span class="block font-mono font-bold text-white text-sm" id="previewInstallment">₹0.00</span>
                    </div>
                </div>
            </div>

            <div class="space-y-1.5">
                <label for="remarks" class="block text-xs font-semibold uppercase tracking-wider text-slate-300">
                    Message to Organizer (Optional)
                </label>
                <input type="text" name="remarks" id="remarks" placeholder="e.g. Please consider my bid for this round"
                    class="w-full glass-input px-4 py-2 rounded-xl text-xs">
            </div>

            <div class="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button type="button" onclick="closeBidModal()" class="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-300 hover:bg-slate-700 transition-colors">
                    Cancel
                </button>
                <button type="submit" id="bidSubmitBtn" class="px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-slate-900 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 transition-all shadow-lg shadow-emerald-500/25">
                    <i class="fa-solid fa-gavel mr-1"></i> <span id="bidSubmitLabel">Submit My Bid</span>
                </button>
            </div>
        </form>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
    // ─────────────────────────────────────────────────
    // BID MODAL — with min-increase enforcement
    // ─────────────────────────────────────────────────
    let _currentMinBid = 0;  // tracks minimum allowed amount for this modal session

    function openBidModal(scheduleId, monthNo, totalAmount, currentBid, remarks) {
        const isEdit = currentBid > 0 && remarks !== '__new__';
        _currentMinBid = isEdit ? parseFloat(currentBid) : 0;

        document.getElementById('bidModalTitle').innerText  = isEdit ? 'Update Your Bid' : 'Place Your Auction Bid';
        document.getElementById('bidModalSubtitle').innerText = 'Month ' + monthNo + ' Auction Round';
        document.getElementById('bidForm').action = '/member/schedules/' + scheduleId + '/bid';
        document.getElementById('currentBidMin').value = _currentMinBid;
        document.getElementById('bid_amount').min   = _currentMinBid;
        document.getElementById('bid_amount').value = currentBid || '';
        document.getElementById('remarks').value    = (remarks === '__new__') ? '' : (remarks || '');
        document.getElementById('bidSubmitLabel').innerText = isEdit ? 'Increase My Bid' : 'Submit My Bid';

        // Show "must increase" notice if editing
        const infoBox = document.getElementById('currentBidInfo');
        if (isEdit && _currentMinBid > 0) {
            document.getElementById('currentBidDisplay').innerText = '₹' + _currentMinBid.toLocaleString('en-IN');
            infoBox.classList.remove('hidden');
        } else {
            infoBox.classList.add('hidden');
        }

        validateBidAmount();
        calculateBidPreview();
        document.getElementById('bidModal').classList.remove('hidden');
    }

    function closeBidModal() {
        document.getElementById('bidModal').classList.add('hidden');
        document.getElementById('bidValidationHint').classList.add('hidden');
    }

    function validateBidAmount() {
        const input   = document.getElementById('bid_amount');
        const hint    = document.getElementById('bidValidationHint');
        const msg     = document.getElementById('bidValidationMsg');
        const submitBtn = document.getElementById('bidSubmitBtn');
        const val     = parseFloat(input.value) || 0;
        const minBid  = parseFloat(document.getElementById('currentBidMin').value) || 0;

        if (minBid > 0 && val < minBid) {
            msg.innerText = 'Bid must be at least ₹' + minBid.toLocaleString('en-IN') + ' (your current bid). You can only increase.';
            hint.classList.remove('hidden');
            submitBtn.disabled = true;
            submitBtn.classList.add('opacity-50', 'cursor-not-allowed');
        } else {
            hint.classList.add('hidden');
            submitBtn.disabled = false;
            submitBtn.classList.remove('opacity-50', 'cursor-not-allowed');
        }
    }

    function calculateBidPreview() {
        const v = parseFloat(document.getElementById('committeeTotalAmount').value) || 0;
        const m = parseFloat(document.getElementById('committeeTotalMembers').value) || 1;
        const d = parseFloat(document.getElementById('bid_amount').value) || 0;
        const netPayout   = Math.max(0, v - d);
        const installment = netPayout / m;
        document.getElementById('previewNetPayout').innerText   = '₹' + netPayout.toLocaleString('en-IN', {minimumFractionDigits: 2});
        document.getElementById('previewInstallment').innerText = '₹' + installment.toLocaleString('en-IN', {minimumFractionDigits: 2});
    }

    // ─────────────────────────────────────────────────
    // ROUND CARD TOGGLE (EXPAND / COLLAPSE)
    // ─────────────────────────────────────────────────
    function toggleRoundCard(scheduleId) {
        const body    = document.getElementById('round-body-' + scheduleId);
        const chevron = document.getElementById('chevron-' + scheduleId);
        body.classList.toggle('hidden');
        chevron.style.transform = body.classList.contains('hidden') ? 'rotate(0deg)' : 'rotate(180deg)';
    }

    // ─────────────────────────────────────────────────
    // REAL-TIME LIVE BIDS — Reliable Polling (5s)
    // ─────────────────────────────────────────────────
    const committeeId = <?php echo e($committee->id); ?>;
    const myMemberId  = <?php echo e($member->id); ?>;
    const alreadyWon  = <?php echo e($alreadyWon ? 'true' : 'false'); ?>;
    const liveBidsUrl = '/member/committees/' + committeeId + '/live-bids';

    let _pollingActive  = true;
    let _abortCtrl      = null;
    let _prevBidHash    = {};   // track bid counts per schedule for change detection
    let _consecutiveFails = 0;

    function formatINR(amount) {
        return '₹' + Number(amount).toLocaleString('en-IN', {minimumFractionDigits: 0, maximumFractionDigits: 0});
    }

    function buildBidRowHTML(bid, idx) {
        const isMe = bid.member_id === myMemberId;
        const rankIcon = idx === 0
            ? '<div class="w-6 h-6 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center text-[10px] font-black shrink-0" title="Lowest Bid"><i class="fa-solid fa-star"></i></div>'
            : `<div class="w-6 h-6 rounded-lg bg-slate-800 border border-slate-700 text-slate-400 flex items-center justify-center text-[10px] font-bold shrink-0">${idx+1}</div>`;
        const statusBadge = bid.status === 'approved'
            ? '<span class="text-[10px] text-emerald-400 font-bold"><i class="fa-solid fa-check-circle mr-0.5"></i>Approved</span>'
            : '<span class="text-[10px] text-slate-500">Pending Review</span>';
        const nameColor    = isMe ? 'text-emerald-300' : 'text-white';
        const amountColor  = isMe ? 'text-emerald-400' : 'text-amber-300';
        const rowBg        = isMe ? 'bg-emerald-500/10 border border-emerald-500/30' : 'bg-slate-900/60 border border-slate-800';
        const youTag       = isMe ? '<span class="text-[10px] text-emerald-400">(You)</span>' : '';
        const remarksHtml  = bid.remarks ? `<span class="block text-[10px] text-slate-400 italic">"${bid.remarks}"</span>` : '';

        return `<div class="flex items-center justify-between p-2.5 rounded-lg ${rowBg}">
            <div class="flex items-center space-x-2.5">
                ${rankIcon}
                <div>
                    <span class="block text-xs font-bold ${nameColor}">${bid.name} ${youTag}</span>
                    ${remarksHtml}
                </div>
            </div>
            <div class="text-right">
                <span class="block font-mono font-black text-sm ${amountColor}">${formatINR(bid.bid_amount)}</span>
                ${statusBadge}
            </div>
        </div>`;
    }

    function applyLiveBidsData(data) {
        const locks = data.lock_status || {};
        const bids  = data.bids || {};
        let   pageNeedsReload = false;

        Object.entries(locks).forEach(([sid, info]) => {
            const card    = document.getElementById('schedule-card-' + sid);
            const bidList = document.querySelector('.bid-list-' + sid);
            if (!card) return;

            const wasLocked  = card.dataset.isLocked === 'true';
            const isNowLocked = info.is_locked;

            // ── Lock status changed → reload page once (updates button states) ──
            if (wasLocked !== isNowLocked) {
                pageNeedsReload = true;
            }

            // ── Update bid count badges ──
            const bidArr = (bids[sid] || []).sort((a,b) => a.bid_amount - b.bid_amount);
            document.querySelectorAll('.bid-count-' + sid).forEach(el => {
                el.innerText = bidArr.length;
            });

            // ── Update card header: My Bid amount shown in quick view ──
            const myBidObj = bidArr.find(b => b.member_id === myMemberId);
            const quickBidEl = document.getElementById('quick-mybid-' + sid);
            if (quickBidEl && myBidObj) {
                quickBidEl.innerText = formatINR(myBidObj.bid_amount);
                quickBidEl.closest('[id^="mybid-wrap"]') && quickBidEl.closest('[id^="mybid-wrap"]').classList.remove('hidden');
            }

            // ── Rebuild bid list only if changed ──
            const newHash = bidArr.map(b => b.id + ':' + b.bid_amount + ':' + b.status).join('|');
            if (_prevBidHash[sid] !== newHash && bidList) {
                _prevBidHash[sid] = newHash;
                if (bidArr.length === 0) {
                    bidList.innerHTML = '<div class="text-center py-4 text-slate-500 text-xs italic">No bids placed yet. Be the first!</div>';
                } else {
                    bidList.innerHTML = bidArr.map((b, i) => buildBidRowHTML(b, i)).join('');
                }
            }
        });

        if (pageNeedsReload) {
            // Brief delay so user sees the update notification
            setTimeout(() => window.location.reload(), 1200);
        }
    }

    function fetchLiveBids() {
        if (!_pollingActive) return;

        // Cancel any in-flight request
        if (_abortCtrl) _abortCtrl.abort();
        _abortCtrl = new AbortController();

        fetch(liveBidsUrl, {
            signal: _abortCtrl.signal,
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }
        })
        .then(res => {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.json();
        })
        .then(data => {
            _consecutiveFails = 0;
            applyLiveBidsData(data);

            // Update live status indicator → green pulse
            const badge = document.getElementById('liveStatusBadge');
            const timeEl = document.getElementById('lastUpdatedTime');
            if (badge) badge.className = 'inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-wider';
            if (timeEl) timeEl.innerText = 'Updated ' + new Date().toLocaleTimeString('en-IN', {hour:'2-digit', minute:'2-digit', second:'2-digit'});
        })
        .catch(err => {
            if (err.name === 'AbortError') return;  // intentional cancel, ignore
            _consecutiveFails++;
            const badge  = document.getElementById('liveStatusBadge');
            const timeEl = document.getElementById('lastUpdatedTime');
            if (badge) badge.className = 'inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700 text-slate-400 text-[10px] font-bold uppercase tracking-wider';
            if (timeEl) timeEl.innerText = 'Reconnecting... (attempt ' + _consecutiveFails + ')';
        });
    }

    // Auto-expand the first open (non-locked) round on load
    document.addEventListener('DOMContentLoaded', () => {
        const firstOpen = document.querySelector('[data-is-locked="false"]');
        if (firstOpen) {
            const sid    = firstOpen.dataset.scheduleId;
            const body   = document.getElementById('round-body-' + sid);
            const chev   = document.getElementById('chevron-' + sid);
            if (body) { body.classList.remove('hidden'); }
            if (chev) { chev.style.transform = 'rotate(180deg)'; }
        }

        // Initial fetch immediately, then every 5 seconds
        fetchLiveBids();
        setInterval(fetchLiveBids, 5000);

        // Pause polling when tab is hidden (saves resources)
        document.addEventListener('visibilitychange', () => {
            _pollingActive = !document.hidden;
            if (_pollingActive) fetchLiveBids();  // resume instantly when tab is active again
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/kameti/resources/views/member_portal/show.blade.php ENDPATH**/ ?>